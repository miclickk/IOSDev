// =============================================================
//  Station ALMA-7, Part II: The Teleporter Incident
//  iOS Mobile Development · Module 4 · Lab Assignment
//
//  How to use:
//   • Xcode: File → New → Playground → Blank, replace everything
//     with this file's contents.
//   • Terminal: swift ALMA7_Part2_Starter.swift
//
//  Rules:
//   • Do NOT modify the STARTER DATA section.
//   • `!` (force unwrap) is forbidden: −0.5 points each.
//   • No map / filter / reduce / compactMap.
//   • Default to struct. Use class only where the task says so.
// =============================================================


// MARK: - =================== STARTER DATA ===================
// MARK: - Do not modify anything in this section

/// Splits a line into fields.
/// fields("crate:101:120")            -> ["crate", "101", "120"]
/// fields("livestock:lab mice:12:2")  -> ["livestock", "lab mice", "12", "2"]
/// fields("junk")                     -> ["junk"]
func fields(_ line: String, separatedBy separator: Character = ":") -> [String] {
    var result: [String] = []
    var current = ""
    for character in line {
        if character == separator {
            result.append(current)
            current = ""
        } else {
            current.append(character)
        }
    }
    result.append(current)
    return result
}

/// Cargo manifest as recovered from the damaged recorder.
let rawManifest = [
    "crate:101:120",
    "container:KZ-ALM-7:340",
    "livestock:lab mice:12:2",
    "???-corrupted-line",
    "crate:102:75",
    "container:KZ-ALM-9:410",
    "livestock:ficus:3:5",
    "crate:103:260",
    "crate:104:abc",
    ""
]

/// Oxygen readings. One of these deck names is not a real deck.
let deckReadings: [(deck: String, oxygen: Int)] = [
    (deck: "bridge",     oxygen: 78),
    (deck: "lab",        oxygen: 64),
    (deck: "greenhouse", oxygen: 55),
    (deck: "cargo",      oxygen: 12),
    (deck: "medbay",     oxygen: 90),
    (deck: "engine",     oxygen: 41)
]

/// Crew records, straight from the personnel file.
let crewData: [(name: String, deck: String, oxygen: Int)] = [
    (name: "Timur",   deck: "engine", oxygen: 62),
    (name: "Dana",    deck: "lab",    oxygen: 48),
    (name: "Aigerim", deck: "bridge", oxygen: 91),
    (name: "Nurlan",  deck: "cargo",  oxygen: 17)
]

print("ALMA-7 recorder online: \(rawManifest.count) manifest lines, \(deckReadings.count) readings, \(crewData.count) crew records.")

// MARK: - ================= END OF STARTER DATA =================


// MARK: - =================== YOUR SOLUTION ===================

// MARK: Level 1 · The Deck Register

// 1.1
enum Deck: String, CaseIterable {
    case bridge
    case lab
    case cargo
    case medbay
    case engine

    var evacuationPriority: Int {
        switch self {
        case .bridge:
            return 1
        case .medbay:
            return 2
        case .lab:
            return 3
        case .engine:
            return 4
        case .cargo:
            return 5
        }
    }
}

print("\n--- Level 1.1: Decks & Priorities ---")
for deck in Deck.allCases {
    print("Deck: \(deck.rawValue), Priority: \(deck.evacuationPriority)")
}
print("Total decks registered: \(Deck.allCases.count)")

// 1.2
enum AlarmLevel: Int {
    case green = 0
    case yellow
    case orange
    case red

    static func level(forTotalMass mass: Int) -> AlarmLevel {
        let step = mass / 500
        if let alarm = AlarmLevel(rawValue: step) {
            return alarm
        } else {
            return .red
        }
    }
}

print("\n--- Level 1.2: Alarm Levels ---")
print("Mass 0kg: \(AlarmLevel.level(forTotalMass: 0))")
print("Mass 940kg: \(AlarmLevel.level(forTotalMass: 940))")
print("Mass 4000kg: \(AlarmLevel.level(forTotalMass: 4000))")


// MARK: Level 2 · The Manifest

// 2.1
enum ManifestEntry {
    case crate(id: Int, massKg: Int)
    case container(code: String, massKg: Int)
    case livestock(species: String, count: Int, massPerUnitKg: Int)
    case unknown(raw: String)
}

// 2.2
func parseEntry(_ line: String) -> ManifestEntry {
    let parts = fields(line, separatedBy: ":")
    guard let tag = parts.first else {
        return .unknown(raw: line)
    }

    switch tag {
    case "crate":
        if parts.count == 3,
           let id = Int(parts[1]),
           let mass = Int(parts[2]) {
            return .crate(id: id, massKg: mass)
        }
    case "container":
        if parts.count == 3,
           let mass = Int(parts[2]) {
            return .container(code: parts[1], massKg: mass)
        }
    case "livestock":
        if parts.count == 4,
           let count = Int(parts[2]),
           let massPerUnit = Int(parts[3]) {
            return .livestock(species: parts[1], count: count, massPerUnitKg: massPerUnit)
        }
    default:
        break
    }
    return .unknown(raw: line)
}

// 2.3
func mass(of entry: ManifestEntry) -> Int {
    switch entry {
    case let .crate(_, massKg):
        return massKg
    case let .container(_, massKg):
        return massKg
    case let .livestock(_, count, massPerUnitKg):
        return count * massPerUnitKg
    case .unknown:
        return 0
    }
}

print("\n--- Level 2.3: Parsing Manifest ---")
var totalManifestMass = 0
var unknownCount = 0

for line in rawManifest {
    let entry = parseEntry(line)
    let entryMass = mass(of: entry)
    totalManifestMass += entryMass
    switch entry {
    case .unknown:
        unknownCount += 1
    default:
        break
    }
}

print("Total parsed manifest mass: \(totalManifestMass) kg")
print("Unknown/corrupted entries count: \(unknownCount)")

let A = totalManifestMass


// MARK: Level 3 · Crew Snapshots

// 3.1
struct CrewSnapshot {
    let name: String
    var deck: Deck
    var oxygen: Int

    mutating func breathe(amount: Int) {
        oxygen -= amount
        if oxygen < 0 {
            oxygen = 0
        }
    }

    mutating func move(to deck: Deck) {
        self.deck = deck
    }

    mutating func reviveInMedbay() {
        self = CrewSnapshot(name: self.name, deck: .medbay, oxygen: 100)
    }

    static func rookie(named name: String) -> CrewSnapshot {
        return CrewSnapshot(name: name, deck: .bridge, oxygen: 100)
    }
}

// 3.2
var crewRoster: [CrewSnapshot] = []
print("\n--- Level 3.2: Building Roster ---")
for record in crewData {
    if let deck = Deck(rawValue: record.deck) {
        crewRoster.append(CrewSnapshot(name: record.name, deck: deck, oxygen: record.oxygen))
    } else {
        print("Warning: Unknown deck '\(record.deck)' for crew member \(record.name). Skipped.")
    }
}
print("Crew roster assembled: \(crewRoster.count) members.")

// 3.3
print("\n--- Level 3.3: Value Semantics Demonstration ---")
// 1. Copy mutation vs original
var originalCrew = CrewSnapshot.rookie(named: "Askar")
var copiedCrew = originalCrew
print("1. Before copy change: original oxygen = \(originalCrew.oxygen), copy oxygen = \(copiedCrew.oxygen)")
copiedCrew.breathe(amount: 40)
print("   After copy change:  original oxygen = \(originalCrew.oxygen), copy oxygen = \(copiedCrew.oxygen)")

// 2. Plain parameter
func simulateBreathing(member: CrewSnapshot) {
    var mutableCopy = member
    mutableCopy.breathe(amount: 30)
}
print("2. Before plain function: original oxygen = \(originalCrew.oxygen)")
simulateBreathing(member: originalCrew)
print("   After plain function:  original oxygen = \(originalCrew.oxygen)")

// 3. inout parameter
func applyBreathing(member: inout CrewSnapshot) {
    member.breathe(amount: 30)
}
print("3. Before inout call: original oxygen = \(originalCrew.oxygen)")
applyBreathing(member: &originalCrew)
print("   After inout call:  original oxygen = \(originalCrew.oxygen)")


// MARK: Level 4 · The Teleport Pod

// 4.1
final class TeleportPod {
    let id: String
    var chargeLevel: Int
    var occupant: CrewSnapshot?

    // TeleportPod is a class and lacks the free memberwise initializer provided automatically to structs.
    // Therefore, an explicit initializer is required.
    init(id: String, chargeLevel: Int) {
        self.id = id
        self.chargeLevel = chargeLevel
        self.occupant = nil
    }

    func load(crew: CrewSnapshot) -> Bool {
        if occupant != nil || chargeLevel < 20 {
            return false
        }
        occupant = crew
        return true
    }

    func fire() -> CrewSnapshot? {
        guard let passenger = occupant else {
            return nil
        }
        chargeLevel -= 20
        occupant = nil
        return passenger
    }

    // Bonus 1: deinit
    deinit {
        print("[Deinit] TeleportPod \(id) has been deallocated.")
    }
}

// 4.2
print("\n--- Level 4.2: Charge Ledger ---")
let pod1 = TeleportPod(id: "P-1", chargeLevel: 100)

let timur = CrewSnapshot(name: "Timur", deck: .engine, oxygen: 62)
_ = pod1.load(crew: timur)
_ = pod1.fire()
print("Step 1 (Timur): Charge = \(pod1.chargeLevel)")

let dana = CrewSnapshot(name: "Dana", deck: .lab, oxygen: 48)
_ = pod1.load(crew: dana)
_ = pod1.fire()
print("Step 2 (Dana): Charge = \(pod1.chargeLevel)")

let nurlan = CrewSnapshot(name: "Nurlan", deck: .cargo, oxygen: 17)
_ = pod1.load(crew: nurlan)
_ = pod1.fire()
print("Step 3 (Nurlan): Charge = \(pod1.chargeLevel)")

_ = pod1.fire()
print("Step 4 (Empty pod fire): Charge = \(pod1.chargeLevel)")

let C = pod1.chargeLevel

// 4.3 Reference semantics demonstration
print("\n--- Level 4.3: Reference Semantics Demonstration ---")
let podRefA = TeleportPod(id: "DemoPod", chargeLevel: 100)
let podRefB = podRefA
print("Before pod mutation: podRefA charge = \(podRefA.chargeLevel), podRefB charge = \(podRefB.chargeLevel)")
podRefB.chargeLevel = 50
print("After podRefB mutation: podRefA charge = \(podRefA.chargeLevel), podRefB charge = \(podRefB.chargeLevel)")

var snapA = CrewSnapshot.rookie(named: "DemoCrew")
var snapB = snapA
print("Before struct mutation: snapA oxygen = \(snapA.oxygen), snapB oxygen = \(snapB.oxygen)")
snapB.oxygen = 25
print("After snapB mutation:   snapA oxygen = \(snapA.oxygen), snapB oxygen = \(snapB.oxygen)")
// Rule demonstrated: Classes share a single mutable instance across references, while structs create distinct, independent copies on assignment.


// MARK: Level 5 · Station Systems

// 5.1
final class Station {
    let callSign: String

    var hullIntegrity: Int {
        willSet {
            print("[HullIntegrity] Transitioning from \(hullIntegrity) to \(newValue)")
        }
        didSet {
            if hullIntegrity < 0 {
                hullIntegrity = 0
            } else if hullIntegrity > 100 {
                hullIntegrity = 100
            }
        }
    }

    lazy var fullDiagnostics: String = {
        print("Running full scan...")
        return "Station \(callSign): All systems nominal."
    }()

    var oxygenByDeck: [Deck: Int] = [:]

    var totalOxygen: Int {
        var total = 0
        for (_, oxygen) in oxygenByDeck {
            total += oxygen
        }
        return total
    }

    var averageOxygen: Int {
        get {
            guard !oxygenByDeck.isEmpty else { return 0 }
            return totalOxygen / oxygenByDeck.count
        }
        set {
            for deck in oxygenByDeck.keys {
                oxygenByDeck[deck] = newValue
            }
        }
    }

    init(callSign: String, initialIntegrity: Int, readings: [(deck: String, oxygen: Int)]) {
        self.callSign = callSign
        self.hullIntegrity = initialIntegrity
        for reading in readings {
            if let deck = Deck(rawValue: reading.deck) {
                self.oxygenByDeck[deck] = reading.oxygen
            }
        }
    }
}

print("\n--- Level 5.1: Station Systems ---")
let station = Station(callSign: "ALMA-7", initialIntegrity: 100, readings: deckReadings)
let B = station.averageOxygen
print("Starting total oxygen: \(station.totalOxygen)")
print("Starting average oxygen (Fragment B): \(B)")

print("Accessing lazy property fullDiagnostics:")
print("First access output: \(station.fullDiagnostics)")
print("Second access output: \(station.fullDiagnostics)")

// 5.2
print("\n--- Level 5.2: The Clamp Trap ---")
// Setting hullIntegrity to 130, -40, then 55
station.hullIntegrity = 130
print("Clamped hull integrity: \(station.hullIntegrity)")
station.hullIntegrity = -40
print("Clamped hull integrity: \(station.hullIntegrity)")
station.hullIntegrity = 55
print("Clamped hull integrity: \(station.hullIntegrity)")
// Inside didSet, reassigning to the same property updates the storage directly without triggering willSet or didSet again, preventing an infinite recursion loop.


// MARK: Level 6 · Incident Reports

// Report 1
// Expected: The crew members in `roster` would have their oxygen reduced by 10.
// Actual: `roster[0].oxygen` remains unchanged.
// Rule: `for var member in roster` creates a local copy on each iteration due to struct value semantics. Mutating the copy does not affect the array element.
// Fix:
var roster = crewRoster
for i in 0..<roster.count {
    roster[i].oxygen -= 10
}
print("Report 1 Fixed: roster[0].oxygen = \(roster[0].oxygen)")

// Report 2
// Expected: podA.chargeLevel to remain 100.
// Actual: podA.chargeLevel becomes 0.
// Rule: `TeleportPod` is a class (reference type). `podB = podA` copies the reference pointing to the same instance on the heap.
// Fix:
let podA = TeleportPod(id: "A", chargeLevel: 100)
let podB = TeleportPod(id: "B", chargeLevel: podA.chargeLevel)
podB.chargeLevel = 0
print("Report 2 Fixed: podA charge = \(podA.chargeLevel), podB charge = \(podB.chargeLevel)")

// Report 3
// Expected: A method on struct Logbook to append a string entry into `entries`.
// Actual: Compile error: "Cannot use mutating member on immutable value: 'self' is immutable".
// Rule: Struct methods cannot mutate stored properties unless declared with the `mutating` keyword.
// Fix:
struct Logbook {
    var entries: [String] = []
    mutating func add(_ entry: String) {
        entries.append(entry)
    }
}
var logbook = Logbook()
logbook.add("Test log entry")
print("Report 3 Fixed: entries count = \(logbook.entries.count)")

// Report 4
// Expected: Both reassignments to work or fail equally.
// Actual: `snapshot.oxygen = 40` causes a compile error: "Cannot assign to property: 'snapshot' is a 'let' constant". `pod.chargeLevel = 10` compiles fine.
// Rule: For a struct (value type), `let` makes the entire memory layout completely immutable, freezing all its stored properties. For a class (reference type), `let` only freezes the pointer/reference from being reassigned to a different instance; the internal mutable properties on the heap can still be modified.
// Fix:
var mutableSnapshot = CrewSnapshot.rookie(named: "Dana")
mutableSnapshot.oxygen = 40
let pod = TeleportPod(id: "B", chargeLevel: 50)
pod.chargeLevel = 10
print("Report 4 Fixed: snapshot oxygen = \(mutableSnapshot.oxygen), pod charge = \(pod.chargeLevel)")


// MARK: Level 7 · Sealing the Black Box

final class FlightRecorder {
    // Accessible only within this type; prevents external code from clearing or resetting the storage
    private var entries: [String] = []

    // Read-only externally; prevents external code from setting isSealed back to false
    private(set) var isSealed = false

    // Allows external inspection of entry count without exposing the array directly
    var entryCount: Int {
        return entries.count
    }

    // Accessible within the same source file so the helper auditTranscript can inspect raw data
    fileprivate var sealedEntriesSnapshot: [String] {
        return entries
    }

    // Public method with guard preventing additions after sealing
    func add(entry: String) -> Bool {
        guard !isSealed else { return false }
        entries.append(entry)
        return true
    }

    // Public one-way transition to seal the recorder
    func seal() {
        isSealed = true
    }

    // Formatted read-only transcript
    func formattedTranscript() -> String {
        var output = ""
        for entry in entries {
            output += "LOG: \(entry)\n"
        }
        return output
    }
}

// Free function using the fileprivate helper
func auditTranscript(of recorder: FlightRecorder) -> String {
    let items = recorder.sealedEntriesSnapshot
    return "Audit complete. Verified \(items.count) entries."
}

print("\n--- Level 7: Flight Recorder Access Control ---")
let flightRecorder = FlightRecorder()
_ = flightRecorder.add(entry: "Liftoff confirmed")
_ = flightRecorder.add(entry: "Orbit stabilized")
flightRecorder.seal()
_ = flightRecorder.add(entry: "Malicious override entry")
print("Recorder count after attempted write to sealed box: \(flightRecorder.entryCount)")
print(auditTranscript(of: flightRecorder))

// Verification of access control limits:
// Attempt 1: flightRecorder.entries = []
// Compiler Error: 'entries' is inaccessible due to 'private' protection level.
// Attempt 2: flightRecorder.isSealed = false
// Compiler Error: Cannot assign to property: 'isSealed' setter is inaccessible.


// MARK: Finale · Integrity Code

let D = AlarmLevel.level(forTotalMass: A).rawValue
let integrityCode = "\(A)-\(B)-\(C)-\(D)"
print("\n==================================")
print("INTEGRITY CODE: \(integrityCode)")
print("==================================")

// MARK: - ================= DEFENSE QUESTIONS =================
/*
 1. Why did CrewSnapshot get an initializer for free and TeleportPod did not?
 Structs get an automatic memberwise init from the compiler, while classes do not because of inheritance complexity, so a class needs its own init written out.
 2. What does `mutating` do to self, and why do classes never need it?
 In structs, self is a constant by default, and mutating turns it into an inout parameter to allow modifying properties. In classes, mutations happen in heap memory without changing the reference pointer itself, so mutating is never needed.
 3. In Report 4 both values are `let`. What exactly does `let` freeze for a struct, and what does it freeze for a class?
 For a struct, let locks down the entire value and all its properties. For a class, let only locks the reference pointer to the instance, so internal var properties can still be modified.

 4. Why must a lazy property be var? When does lazy change behaviour, not just performance?
 A lazy property gets its value after object initialization, which requires a mutable var. It changes behavior if initialization has side effects, making the outcome depend on the exact moment the property is first accessed.

 5. private vs fileprivate: where in your FlightRecorder would private be too strict?
 The auditTranscript helper function lives outside the class body. Marking the property private would hide it completely, while fileprivate lets code in the same file access it while keeping it hidden from the rest of the project.
*/
