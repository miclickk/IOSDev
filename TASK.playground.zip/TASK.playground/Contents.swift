// =============================================================
//  Station ALMA-7: Rescue Protocol
//  iOS Mobile Development · Module 3 · Lab Assignment
//
//  How to use:
//   • Xcode: File → New → Playground → Blank, replace everything
//     with this file's contents.
//   • Terminal: swift ALMA7_Starter.swift
//
//  Rules:
//   • Do NOT modify the STARTER CODE section.
//   • `!` (force unwrap) is forbidden: −0.5 points each.
//   • No map / filter / reduce / compactMap.
//   • Use the exact function names from the assignment PDF.
// =============================================================


// MARK: - =================== STARTER CODE ===================
// MARK: - Do not modify anything in this section

typealias Reading = (sensor: String, value: Int)

/// Splits a string at the first occurrence of the separator.
/// splitOnce("O2:87", by: ":") -> ("O2", "87")
/// splitOnce("hello", by: ":") -> nil
func splitOnce(_ line: String, by separator: Character) -> (String, String)? {
    guard let index = line.firstIndex(of: separator) else { return nil }
    let left = String(line[..<index])
    let right = String(line[line.index(after: index)...])
    return (left, right)
}

let rawLog = [
    "O2:87", "TEMP:-12", "O2:9x", "PRESS:101", "TEMP:abc", "O2:",
    "RAD:3", "O2:64", ":55", "TEMP:31", "PRESS:98", "O2:71",
    "RAD:-1", "TEMP:4", "PRESS:1o2", "O2:90"
]

class Tank {
    var level: Int
    init(level: Int) { self.level = level }
}

class Module {
    let name: String
    var oxygenTank: Tank?
    init(name: String, oxygenTank: Tank?) {
        self.name = name
        self.oxygenTank = oxygenTank
    }
}

class CrewMember {
    let name: String
    let role: String
    let priority: Int      // 1 = evacuated first
    var module: Module?    // nil = in open space
    init(name: String, role: String, priority: Int, module: Module?) {
        self.name = name
        self.role = role
        self.priority = priority
        self.module = module
    }
}

let lab  = Module(name: "Lab",  oxygenTank: Tank(level: 40))
let hab  = Module(name: "Hab",  oxygenTank: Tank(level: 12))
let dock = Module(name: "Dock", oxygenTank: nil)

let crew = [
    CrewMember(name: "Timur",   role: "Engineer",  priority: 3, module: lab),
    CrewMember(name: "Dana",    role: "Scientist", priority: 4, module: dock),
    CrewMember(name: "Aigerim", role: "Commander", priority: 1, module: hab),
    CrewMember(name: "Nurlan",  role: "Pilot",     priority: 2, module: nil)
]

var roster: [String: CrewMember] = [:]
for member in crew { roster[member.name] = member }

print("ALMA-7 systems online: \(rawLog.count) log lines, \(crew.count) crew members.")

// MARK: - ================= END OF STARTER CODE =================


// MARK: - =================== YOUR SOLUTION ===================
// Uncomment each signature when you start working on it.


// MARK: Level 1 · Decoding Telemetry

// 1.1
func parseReading(_ raw: String) -> Reading? {
     guard let parts = splitOnce(raw, by: ":"),
               parts.0.isEmpty == false,
               let value = Int(parts.1),
               parts.0 == "TEMP" || value >= 0 else {
             return nil
         }
         return (sensor: parts.0, value: value)
     }

// 1.2
func parseLog(_ lines: [String]) -> (valid: [Reading], invalidCount: Int) {
var validReadings: [Reading] = []
var errors = 0
    
    for line in lines {
        if let reading = parseReading(line) {
            validReadings.append(reading)
        } else {
            errors += 1
        }
    }
    return (valid: validReadings, invalidCount: errors)
}

let parsed = parseLog(rawLog)
let A = parsed.invalidCount


// MARK: Level 2 · Analysis

// 2.1
func select(_ readings: [Reading], where isIncluded: (Reading) -> Bool) -> [Reading] {
    var result: [Reading] = []
    for item in readings {
        if isIncluded(item) {
            result.append(item)
        }
    }
    return result
}

func values(of readings: [Reading]) -> [Int] {
    var result: [Int] = []
    for item in readings {
        result.append(item.value)
    }
    return result
}

// 2.2
func stats(of values: [Int]) -> (min: Int, max: Int, average: Double)? {
    guard values.isEmpty == false else { return nil }
    
    var minVal = values[0]
    var maxVal = values[0]
    var sum = 0
    
    for v in values {
        if v < minVal { minVal = v }
        if v > maxVal { maxVal = v }
        sum += v
    }
    
    let avg = Double(sum) / Double(values.count)
    return (min: minVal, max: maxVal, average: avg)
}


func stats(_ values: Int...) -> (min: Int, max: Int, average: Double)? {
    stats(of: values)
}

let o2Readings = select(parsed.valid) { $0.sensor == "O2" }
let B = Int(stats(of: values(of: o2Readings))?.average ?? 0)

// 2.3 · The Closure Ladder
let data = parsed.valid
let sort1 = data.sorted(by: { (a: Reading, b: Reading) -> Bool in return a.value > b.value })
let sort2 = data.sorted(by: { a, b in return a.value > b.value })
let sort3 = data.sorted(by: { a, b in a.value > b.value })
let sort4 = data.sorted(by: { $0.value > $1.value })
let sort5 = data.sorted { $0.value > $1.value }


// MARK: Level 3 · Temperature Stabilization

// 3.1
func heatUp(_ t: Int) -> Int { return t + 5 }
func coolDown(_ t: Int) -> Int { return t - 3 }
func hold(_ t: Int) -> Int { return t }

func chooseProtocol(for temp: Int) -> (Int) -> Int {
    if temp < 18 {
        return heatUp
    } else if temp > 24 {
        return coolDown
    } else {
        return hold
    }
}

// 3.2
func runUntilStable(from start: Int, maxSteps: Int = 10) -> (finalTemp: Int, steps: Int, isStable: Bool) {
    var temp = start
    var stepCount = 0
    
    while (temp < 18 || temp > 24) && stepCount < maxSteps {
        let action = chooseProtocol(for: temp)
        temp = action(temp)
        stepCount += 1
    }
    
    let stable = (temp >= 18 && temp <= 24)
    return (finalTemp: temp, steps: stepCount, isStable: stable)
}

let tempReadings = select(parsed.valid) { $0.sensor == "TEMP" }
let minTemp = stats(of: values(of: tempReadings))?.min ?? 0
let C = runUntilStable(from: minTemp).steps


// MARK: Level 4 · The Crew

// 4.1
func oxygenLevel(of member: CrewMember) -> Int? {
    return member.module?.oxygenTank?.level
}

// 4.2
func status(of member: CrewMember) -> String {
    guard let level = oxygenLevel(of: member) else {
        let place = member.module?.name ?? "open space"
        return "\(member.name): no data (\(place))"
    }
    
    if level < 20 {
        return "\(member.name): \(level)% CRITICAL"
    } else {
        return "\(member.name): \(level)% OK"
    }
}

for m in crew { print(status(of: m)) }

// 4.3
@discardableResult
func transferOxygen(from source: inout Int, to target: inout Int, amount: Int) -> Int {
    if amount <= 0 { return 0 }
    
    var actual = amount
    if actual > source { actual = source }
    if target + actual > 100 { actual = 100 - target }
    
    source -= actual
    target += actual
    return actual
}

if let labTank = lab.oxygenTank, let habTank = hab.oxygenTank {
    transferOxygen(from: &labTank.level, to: &habTank.level, amount: 30)
}
let D = hab.oxygenTank?.level ?? 0

// 4.4
func evacuationOrder(_ names: String..., roster: [String: CrewMember]) -> [String] {
    var foundMembers: [CrewMember] = []
    
    for name in names {
        guard let member = roster[name] else {
            print("Unknown crew member: \(name)")
            continue
        }
        foundMembers.append(member)
    }
    
    foundMembers.sort { $0.priority < $1.priority }
    
    var resultNames: [String] = []
    for member in foundMembers {
        resultNames.append(member.name)
    }
    return resultNames
}

// MARK: Level 5 · The Saboteur's Logbook
// The saboteur's code is below, commented out (it needs your
// oxygenLevel(of:) to compile). Comment on every problem, then
// write fixed versions and a test that proves the logic bug is gone.
func reportOxygen(for member: CrewMember) -> String {
    if let tank = member.module?.oxygenTank {
        return "\(member.name): \(tank.level)%"
    } else {
        return "\(member.name): no tank"
    }
}


func firstCritical(in crew: [CrewMember]) -> String? {
    for member in crew {
        if let level = oxygenLevel(of: member), level < 20 {
            return member.name
        }
    }
    return nil
}


let testCrew = [
    CrewMember(name: "Aigerim", role: "Cmdr", priority: 1, module: Module(name: "Hab", oxygenTank: Tank(level: 10))),
    CrewMember(name: "Dana", role: "Sci", priority: 4, module: Module(name: "Dock", oxygenTank: Tank(level: 5)))
]
print("First critical: \(firstCritical(in: testCrew) ?? "Nobody")")


// MARK: Finale · Launch Code
let launchCode = "\(A)-\(B)-\(C)-\(D)"
print("LAUNCH CODE: \(launchCode)")

// MARK: Bonus

// func makeAlarm(threshold: Int) -> (Int) -> Bool { }


// MARK: - ================= DEFENSE QUESTIONS =================
/*
 1. guard let vs if let beyond syntax:
 guard let требует досрочного выхода зато переменная остается доступна дальше без лишних скобок.

 2. Why can't you pass [Int] to stats(_ values: Int...)?
    Вариативный параметр Int... ждет числа поштучно через запятую (1, 2, 3). свифт не умеет автоматически распаковывать готовый массив в список аргументов.

 3. Why doesn't transferOxygen(from: &x, to: &x, amount: 5) compile?
 Swift запрещает одновременный эксклюзивный доступ к одной ячейке памяти

 4. Why doesn't oxygenLevel(of: dana) ?? "no data" compile?
 Для оператора ?? типы слева и справа должны совпадать
 оксиген лвл-число, но дата - текст
 
 5. Full type of chooseProtocol and how to read it:

 Bonus. Where does the alarm counter live after makeAlarm returns?

*/
